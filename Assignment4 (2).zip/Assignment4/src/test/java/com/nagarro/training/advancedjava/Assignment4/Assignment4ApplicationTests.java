package com.nagarro.training.advancedjava.Assignment4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
